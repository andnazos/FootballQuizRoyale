# QuizApp
ABSTRACT

In this thesis, which was carried out at the Department of Electrical and
Computer Engineering (ECE) of the University of Peloponnese, which
belongs to the School of Engineering based in Patras, an Android
application was developed with the aim of conducting a group Quiz on
football knowledge. In this app, two teams are pitted against each other
in a challenging Quiz, aiming to achieve victory. It is necessary to have at
least two (2) people to start the Quiz. At the conclusion of the Quiz, only
one winning team emerges, but knowledge and fun are always shared
among all participants.
The reasons that led us to choose this topic are the lack of a two-team
football Quiz Android application in the Greek market, along with our
great interest in the Android platform whose development has been rapid
in recent years and covers a very large part of the market for
smartphones, tablets, wearables, televisions and other technological
media.

Link : https://drive.google.com/file/d/1GJWAkX12505LVzpWwwmJjMPMocFVHsO6/view?usp=drive_link
